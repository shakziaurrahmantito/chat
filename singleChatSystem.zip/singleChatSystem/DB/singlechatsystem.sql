-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2022 at 04:14 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `singlechatsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `message_history`
--

CREATE TABLE `message_history` (
  `id` int(11) NOT NULL,
  `msg` varchar(250) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_time` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message_history`
--

INSERT INTO `message_history` (`id`, `msg`, `user_id`, `date_time`) VALUES
(16, 'Aslamuaikum', 4, '04:19:36 pm 27-05-2022'),
(17, 'Oyakum Aslam', 5, '04:21:07 pm 27-05-2022'),
(18, 'kamom asen?', 5, '04:21:27 pm 27-05-2022'),
(19, 'Alahamdunill valo', 4, '04:21:45 pm 27-05-2022'),
(20, 'Apni?', 4, '04:22:02 pm 27-05-2022'),
(21, 'Hello', 4, '08:40:22 pm 27-05-2022'),
(22, 'hi', 4, '07:16:13 am 28-05-2022'),
(23, 'kamon aso', 4, '07:16:13 am 28-05-2022'),
(24, 'hi', 4, '07:17:49 am 28-05-2022'),
(25, 'hi', 4, '07:19:10 am 28-05-2022'),
(26, 'hi', 4, '07:22:57 am 28-05-2022'),
(27, 'hi', 4, '07:23:47 am 28-05-2022'),
(28, 'hi', 5, '07:24:25 am 28-05-2022'),
(29, 'hi', 4, '07:23:47 am 28-05-2022'),
(30, 'hi', 5, '07:26:53 am 28-05-2022'),
(31, 'hi', 5, '07:27:44 am 28-05-2022'),
(32, 'hi', 5, '07:29:00 am 28-05-2022'),
(33, 'hi', 5, '07:30:43 am 28-05-2022'),
(34, 'hi', 5, '07:33:51 am 28-05-2022'),
(35, 'hi', 5, '07:34:31 am 28-05-2022'),
(36, 'how are you?', 5, '07:34:31 am 28-05-2022'),
(37, 'hi', 5, '07:35:35 am 28-05-2022'),
(38, 'hi', 5, '07:36:03 am 28-05-2022'),
(39, 'how are you?', 5, '07:36:03 am 28-05-2022'),
(40, 'Asalamualikim', 5, '07:36:25 am 28-05-2022'),
(41, 'kamon ase?', 5, '07:36:25 am 28-05-2022'),
(42, 'hi', 5, '07:38:47 am 28-05-2022'),
(43, 'hi', 5, '07:40:06 am 28-05-2022'),
(44, 'hi', 5, '07:41:54 am 28-05-2022'),
(45, 'hi', 5, '07:43:16 am 28-05-2022'),
(46, 'hi', 4, '07:43:14 am 28-05-2022'),
(47, 'kamon asen?', 5, '07:43:16 am 28-05-2022'),
(48, 'hi', 5, '07:43:16 am 28-05-2022'),
(49, 'how are you?', 5, '07:43:16 am 28-05-2022'),
(50, 'I\'m fine', 4, '07:43:14 am 28-05-2022'),
(51, 'good', 4, '07:43:14 am 28-05-2022'),
(52, 'hello', 4, '07:43:14 am 28-05-2022'),
(53, 'hi', 4, '07:44:39 am 28-05-2022'),
(54, 'Aslamuaikum', 5, '07:44:33 am 28-05-2022'),
(55, 'hi', 5, '07:45:54 am 28-05-2022'),
(56, 'how are you?', 5, '07:45:54 am 28-05-2022'),
(57, 'fine', 5, '07:45:54 am 28-05-2022'),
(58, 'good', 4, '07:45:33 am 28-05-2022'),
(59, 'hi', 4, '07:47:10 am 28-05-2022'),
(60, 'hi', 5, '07:45:54 am 28-05-2022'),
(61, 'hi', 4, '07:47:10 am 28-05-2022'),
(62, 'kamon asen?', 6, '07:48:38 am 28-05-2022'),
(63, 'hi', 5, '07:57:17 am 28-05-2022'),
(64, 'hi', 6, '08:02:55 am 28-05-2022'),
(65, 'Hello', 5, '08:02:52 am 28-05-2022'),
(66, 'hi', 5, '08:06:21 am 28-05-2022'),
(67, 'h', 6, '08:07:00 am 28-05-2022'),
(68, 'hi', 4, '07:25:18 am 29-05-2022'),
(69, 'name md. Ziaur Rahman', 4, '07:36:21 am 29-05-2022'),
(70, 'mdserws', 5, '07:47:02 am 29-05-2022'),
(71, 'My name ziaur', 4, '07:47:01 am 29-05-2022'),
(72, 'hi', 5, '07:47:54 am 29-05-2022'),
(73, 'Hello', 5, '07:47:54 am 29-05-2022'),
(74, 'kamon asen?', 5, '07:47:54 am 29-05-2022'),
(75, 'Valo apni?', 5, '07:47:54 am 29-05-2022'),
(76, 'amr sonar bangla ami tomai valovashi', 4, '07:47:53 am 29-05-2022'),
(77, 'I\'m fine.', 4, '07:47:53 am 29-05-2022'),
(78, 'ssss', 4, '07:59:26 am 29-05-2022'),
(79, 'ssssss', 4, '07:59:47 am 29-05-2022'),
(80, 'aaaa', 4, '08:01:17 am 29-05-2022'),
(81, 'ssss', 4, '08:01:46 am 29-05-2022'),
(82, 'ss', 5, '08:01:48 am 29-05-2022'),
(83, 'ssss', 5, '08:01:48 am 29-05-2022'),
(84, 'ssss', 4, '08:03:42 am 29-05-2022'),
(85, 'ssss', 4, '08:04:27 am 29-05-2022'),
(86, 'ssss', 4, '08:04:27 am 29-05-2022'),
(87, 'hi', 4, '08:04:27 am 29-05-2022'),
(88, 'kamon asen?', 4, '08:04:27 am 29-05-2022'),
(89, 'sssssssss', 4, '08:09:17 am 29-05-2022'),
(90, 'sssss', 4, '08:09:17 am 29-05-2022'),
(91, 's', 5, '08:11:07 am 29-05-2022'),
(92, 'ddd', 4, '08:12:01 am 29-05-2022'),
(93, 'name', 4, '08:12:34 am 29-05-2022'),
(94, 'hi', 5, '08:13:01 am 29-05-2022'),
(95, 'kamon asen?', 5, '08:13:01 am 29-05-2022'),
(96, 'valo', 4, '08:12:58 am 29-05-2022'),
(97, 'dddd', 4, '08:12:58 am 29-05-2022'),
(98, 'dddd', 5, '08:13:01 am 29-05-2022'),
(99, 'ss', 5, '08:13:01 am 29-05-2022'),
(100, 'ss', 6, '08:13:52 am 29-05-2022'),
(101, 's', 4, '08:12:58 am 29-05-2022'),
(102, 's', 5, '08:13:01 am 29-05-2022'),
(103, 'suu', 5, '08:13:01 am 29-05-2022'),
(104, 'sdd', 6, '08:13:52 am 29-05-2022'),
(105, 'sss', 6, '08:13:52 am 29-05-2022'),
(106, 'sss', 5, '08:13:01 am 29-05-2022'),
(107, 'ssss', 4, '08:12:58 am 29-05-2022'),
(108, 'ssss', 6, '08:13:52 am 29-05-2022'),
(109, 'ssssss', 5, '08:13:01 am 29-05-2022'),
(110, 'ddd', 4, '08:17:50 am 29-05-2022'),
(111, 'ddd', 4, '08:17:50 am 29-05-2022'),
(112, 'ssssssss', 5, '08:18:09 am 29-05-2022'),
(113, 'ssss', 5, '08:18:09 am 29-05-2022'),
(114, 'aaaaaa', 4, '08:18:34 am 29-05-2022'),
(115, 'dddd', 4, '08:20:14 am 29-05-2022'),
(116, 'sssss', 4, '08:21:03 am 29-05-2022'),
(117, 'ddddd', 4, '08:22:06 am 29-05-2022'),
(118, 'ddd', 5, '08:22:15 am 29-05-2022'),
(119, 'ddddd', 4, '08:22:14 am 29-05-2022'),
(120, 'dddd', 4, '08:23:44 am 29-05-2022'),
(121, 'name', 4, '08:23:44 am 29-05-2022'),
(122, 'name zia', 4, '08:23:44 am 29-05-2022'),
(123, 'sssss', 4, '08:24:44 am 29-05-2022'),
(124, 'tito', 4, '08:25:11 am 29-05-2022'),
(125, 'sssss', 5, '08:25:21 am 29-05-2022'),
(126, 'sssss', 5, '08:25:21 am 29-05-2022'),
(127, 'dddd', 4, '08:26:36 am 29-05-2022'),
(128, 'dddd', 4, '08:26:36 am 29-05-2022'),
(129, 'sss', 4, '08:27:46 am 29-05-2022'),
(130, 'dddd', 5, '08:27:48 am 29-05-2022'),
(131, 'ddddd', 5, '08:29:26 am 29-05-2022'),
(132, 'sssss', 5, '08:29:26 am 29-05-2022'),
(133, 'ddd', 5, '08:30:00 am 29-05-2022'),
(134, 'dddd', 4, '08:30:10 am 29-05-2022'),
(135, 'dddd', 5, '08:30:00 am 29-05-2022'),
(136, 'dddd', 5, '08:30:57 am 29-05-2022'),
(137, 'ddddd', 5, '08:30:57 am 29-05-2022'),
(138, 'dddd', 5, '08:31:45 am 29-05-2022'),
(139, 'ddd', 5, '08:31:45 am 29-05-2022'),
(140, 'ddd', 5, '08:32:14 am 29-05-2022'),
(141, 'aaaa', 4, '08:32:38 am 29-05-2022'),
(142, 'sssssss', 4, '08:34:43 am 29-05-2022'),
(143, 'dddddd', 5, '08:35:41 am 29-05-2022'),
(144, 'dddd', 5, '08:35:41 am 29-05-2022'),
(145, 'dddd', 5, '08:36:32 am 29-05-2022'),
(146, 'ddd', 5, '08:36:32 am 29-05-2022'),
(147, 'dddd', 5, '08:37:48 am 29-05-2022'),
(148, 'ddddd', 5, '08:37:48 am 29-05-2022'),
(149, 'dddd', 5, '08:37:48 am 29-05-2022'),
(150, 'ddddd', 5, '08:37:48 am 29-05-2022'),
(151, 'ddddd', 5, '08:39:56 am 29-05-2022'),
(152, 'dddd', 5, '08:39:56 am 29-05-2022'),
(153, 'ddd', 5, '08:39:56 am 29-05-2022'),
(154, 'ddddd', 5, '08:41:05 am 29-05-2022'),
(155, 'ddddd', 5, '08:41:05 am 29-05-2022'),
(156, 'dddddd', 5, '08:41:05 am 29-05-2022'),
(157, 'dddddd', 5, '08:41:05 am 29-05-2022'),
(158, 'dddddd', 5, '08:41:05 am 29-05-2022'),
(159, 'dddd', 4, '08:42:33 am 29-05-2022'),
(160, 'ddddddddd', 4, '08:42:33 am 29-05-2022'),
(161, 'ddddd', 4, '08:42:33 am 29-05-2022'),
(162, 'dddddd', 5, '08:42:27 am 29-05-2022'),
(163, 'ddd', 5, '08:42:27 am 29-05-2022'),
(164, 'dddd', 4, '08:42:33 am 29-05-2022'),
(165, 'hi', 5, '08:43:16 am 29-05-2022'),
(166, 'kamon aso', 5, '08:43:16 am 29-05-2022'),
(167, 'ssss', 4, '08:43:14 am 29-05-2022'),
(168, 'ddddd', 4, '08:43:14 am 29-05-2022'),
(169, 'ddddd', 5, '08:43:16 am 29-05-2022'),
(170, 'My name is ziaur Rahman', 4, '08:43:14 am 29-05-2022'),
(171, 'ddddd', 5, '08:44:15 am 29-05-2022'),
(172, 'dddd', 6, '08:44:08 am 29-05-2022'),
(173, 'dddd', 4, '08:44:11 am 29-05-2022'),
(174, 'sssssssss', 4, '08:44:11 am 29-05-2022'),
(175, 'ddddd', 4, '08:45:03 am 29-05-2022'),
(176, 'dddddd', 4, '08:45:03 am 29-05-2022'),
(177, 'ddd', 5, '08:45:06 am 29-05-2022'),
(178, 'ssss', 6, '08:45:19 am 29-05-2022'),
(179, 'ddddd', 5, '08:45:06 am 29-05-2022'),
(180, 'dddd', 6, '08:45:19 am 29-05-2022'),
(181, 'ssss', 4, '08:45:03 am 29-05-2022'),
(182, 'Hi', 6, '08:46:32 am 29-05-2022'),
(183, 'hi', 5, '09:45:11 am 29-05-2022'),
(184, 'kamon aso?', 4, '09:45:17 am 29-05-2022'),
(185, 'valo tume?', 5, '09:45:11 am 29-05-2022');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `status`) VALUES
(4, 'Md. Ziaur Rahman', 'shakziaurrahmantito@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1),
(5, 'Md. Tito Mia', 'tito@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1),
(6, 'Md. Rakib Hossain', 'rakibhossain@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `message_history`
--
ALTER TABLE `message_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `message_history`
--
ALTER TABLE `message_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=186;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
