<?php

	$file = realpath(dirname(__FILE__));
	include_once($file."/../lib/session.php");
	include_once($file."/../lib/Database.php");

	$db 		= new DB();
	$Session 	= new Session();
	$Session->init();
?>



<?php 

	if (isset($_POST['action']) && $_POST['action'] == "login") {

		$sql = "SELECT user_id, status FROM user WHERE user_email = :user_email AND user_password = :user_password LIMIT 1";
		$stmt = $db->prepare($sql);
		$stmt->bindValue(":user_email", $_POST['email']);
		$stmt->bindValue(":user_password", md5($_POST['password']));
		$stmt->execute();
		$data = $stmt->fetch(PDO::FETCH_OBJ);
		if ($data) {
			if ($data->status == 2) {
				echo 2;
			}else{
				$Session->set("login", 1);
				$Session->set("user_id", $data->user_id);
				echo 1;
			}
		}else{
			echo "false";
		}

	}	



	if (isset($_GET['action']) && $_GET['action'] == "logout") {
		$Session->destroy();
		echo "1";
	}

	if (isset($_POST['action']) && $_POST['action'] == "message_sent") {
		$sql = "INSERT INTO message_history(msg, user_id, date_time) VALUES(:msg, :user_id, :date_time)";
		$stmt = $db->prepare($sql);
		$stmt->bindValue(":msg", $_POST['message']);
		$stmt->bindValue(":user_id", $_POST['user_id']);
		$stmt->bindValue(":date_time", $_POST['current_date']);
		$stmt->execute();
		echo "1";
	}


	if (isset($_POST['action']) && $_POST['action'] == "singup") {

		$sql = "SELECT user_email FROM user WHERE user_email = :user_email";
		$stmt = $db->prepare($sql);
		$stmt->bindValue(":user_email", $_POST['email']);
		$stmt->execute();
		$data = $stmt->rowCount();
		if ($data > 0) {
			echo "exists";
		}else{

			$sql = "INSERT INTO user(user_name, user_email, user_password) VALUES(:user_name, :user_email, :user_password)";
			$stmt = $db->prepare($sql);
			$stmt->bindValue(":user_name", $_POST['name']);
			$stmt->bindValue(":user_email", $_POST['email']);
			$stmt->bindValue(":user_password", md5($_POST['password']));
			$stmt->execute();
			$data = $stmt->rowCount();
			
			$sql = "SELECT user_id FROM user WHERE user_email = :user_email";
			$stmt = $db->prepare($sql);
			$stmt->bindValue(":user_email", $_POST['email']);
			$stmt->execute();
			$get_id = $stmt->fetch();
			$lastId = $get_id['user_id'];

			if ($data > 0) {
				$Session->set("login", 1);
				$Session->set("user_id", $lastId);
				echo "success";
			}else{
				echo "false";
			}

		}
	}



?>