<?php
  include_once("lib/session.php");
  $Session  = new Session();
  $Session->init();

  if ($Session->get("login") == 1) {
    header("location:index.php");
  }

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>New account</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- <script src="js/jquery.min.js"></script> -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style type="text/css">
      body{background: #ddd;}
    </style>
  </head>
  <body style="background: #ddd;">

    <section class="my-2 p-3 py-5" style="max-width: 450px;margin: auto;">
      <div class="card">
        <div class="card-body">

          <form class="py-5" method="post" id="userSingup">
            <h6 class="text-center text-danger" id="msg"></h6>

            <div class="form-group">
              <label>Name</label>
              <input type="text" name="name" id="name" class="form-control" placeholder="Enter name">
              <small id="errname" class="form-text" style="color:red;"></small>
            </div>

            <div class="form-group">
              <label>Email</label>
              <input type="text" name="email" id="email" class="form-control" placeholder="Valid email address">
              <small id="erremail" class="form-text" style="color:red;"></small>
            </div>

            <div class="form-group">
              <label>Password</label>
              <input type="password" name="password" id="password" class="form-control" placeholder="Strong password">
              <small id="errpassword" class="form-text" style="color:red;"></small>
            </div>

            <input type="submit" value="Create" class="btn btn-primary">
            <br>
            <a href="login.php" class="d-block text-center">Already created</a>
          </form>


          
        </div>
      </div>

    </section>


    <script type="text/javascript">
      

  $("#userSingup").submit(function(){

      var valid = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;

      var name      = $("#name").val();
      var email     = $("#email").val();
      var password  = $("#password").val();

      if ($('#name').val() == "") {
        $("#errname").text("Field must not be empty.");
        return false;
      }else{
        $("#errname").text("");
      }


      if ($('#email').val() == "") {
        $("#erremail").text("Field must not be empty.");
        return false;
      }else if (!valid.test($('#email').val())) {
        $("#erremail").text("Please valid email address.");
        return false;
      }else{
        $("#erremail").text("");
      }

      if ($('#password').val() == "") {
        $("#errpassword").text("Field must not be empty.");
        return false;
      }else{
        $("#errpassword").text("");
      }

      if ($('#name').val() !== "" && $('#email').val() !== "" && $('#password').val() !== "") {

       $.ajax({
            url     : "process/process.php",
            method  : "post",
            data    : {
                  name        : name,
                  email       : email,
                  password    : password,
                  action      : "singup"
            },
            success : function(data){

              var data = $.trim(data);

              if (data == "exists") {
                $("#erremail").html("Email address already exists.");
              }else{
                 $("#erremail").html("");
              }

              if (data == "success") {
                window.location = "index.php";
              }else if(data == "false"){
                $("#msg").html("Something worn");
              }else{
                $("#msg").html("");
              }
            }
        });
      }

      return false;

    });


    </script>
  </body>
</html>