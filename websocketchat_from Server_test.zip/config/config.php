<?php 
	define("DB_NAME","shakziau_chat");
	define("DB_HOST","localhost");
	define("DB_USER","shakziau_chat");
	define("DB_PASSWORD","{Zj2sO9JnbFL");
?>