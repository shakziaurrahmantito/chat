<?php

	$file = realpath(dirname(__FILE__));
	include_once($file."/lib/session.php");
	$Session 	= new Session();
	$Session->init();
	
	include_once($file."/lib/Database.php");


	$db 		= new DB();


	if ($Session->get("login") !== 1) {
 
   		echo "<script>window.location = 'login.php'; </script>";
   		
  	}

	$sql = "SELECT * FROM user WHERE user_id = :user_id LIMIT 1";
	$stmt = $db->prepare($sql);
	$stmt->bindValue(":user_id", $Session->get("user_id"));
	$stmt->execute();
	$data = $stmt->fetch(PDO::FETCH_OBJ);

	if ($data) {
		if ($data->status == 2) {
			$Session->destroy();
			header("location:login.php");
		}
	}

	$time = time();
	date_default_timezone_set("ASIA/Dhaka");
	$current_date = date("h:i:s a d-m-Y", $time);


?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Single Chat System</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/main.css">
	</head>
	<body>


<!-- 		<audio controls id="autoplayaudio">
			<source src="sound/sound.mp3" type="audio/mp3">
		</audio>
 -->
		<section id="personalInfo">
			<div class="container">
				<hr>
				<div style="overflow:hidden;" class="mt-2">
					<h4 class="float-left mytext" style="max-width: 80%;">Welcome! <?php 
					if (isset($data)) {
						echo $data->user_name;
					}
				?></h4>
					<button type="button" id="logout" style="max-width: 20%;" class="btn btn-link float-right">Logout</button>
				</div>
				<hr>
			</div>
			
		</section>
		<section id="messageHistory">
			<div class="container">
				<div id="messageShow" class="scroller" style="overflow: auto;max-height: 360px;">

	<?php 

		$sql = "SELECT * FROM message_history";
		$stmt = $db->prepare($sql);
		$stmt->execute();
		$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
	?>

	<?php 

		if ($data) {
			foreach($data as $key => $value){

				if ($value['user_id'] == $Session->get("user_id")) {
				

	?>

					<div class="mb-2" style="overflow:hidden;">
						<p style="float:right;background: #6868ca;text-align: right;"><?php echo $value['msg']; ?></p>
						<small style="float:right;padding-right: 45px;display: block;text-align: right;">You <?php echo $value['date_time']; ?></small>
					</div>

	<?php 

		}else{

	?>

			<div class="mb-2" style="overflow:hidden;">
				<p style="float:left;background: #9090ae;"><?php echo $value['msg']; ?></p>
				<small style="float:left;padding-left: 45px;display: block;"><?php
				$sql = "SELECT message_history.*, user.* FROM message_history
					INNER JOIN user ON message_history.user_id = user.user_id WHERE message_history.user_id = :user_id LIMIT 1";
				$stmt = $db->prepare($sql);
				$stmt->bindValue(":user_id", $value['user_id']);
				$stmt->execute();
				$data = $stmt->fetch(PDO::FETCH_ASSOC);
				echo $data['user_name']." ";
				echo $value['date_time']; ?></small>
			</div>

	<?php 

				}
			}
		}

	?>
			</div>
			<div style="height:25px;background: white;">
				<small id="typeStatus" style="font-style: italic;display: bolck;height: 20px;"></small>




			</div>
				
			</div>
			<div class="container">
				<form class="mb-4 mt-2" autocomplete="off" onsubmit="return false" method="post">
					<div class="input-group">
						<input type="text" name="message" id="message" placeholder="Whatever your mind says........." class="form-control">
						<div class="input-group-append">
							<button type="input" id="message_send" class="btn btn-primary">Send</button>
						</div>
					</div>
				</form>
			</div>
		</section>

		<?php 

			$sql = "SELECT * FROM user WHERE user_id = :user_id LIMIT 1";
			$stmt = $db->prepare($sql);
			$stmt->bindValue(":user_id", $Session->get("user_id"));
			$stmt->execute();
			$data = $stmt->fetch(PDO::FETCH_OBJ);

		?>


		<script type="text/javascript" src="node_modules/socket.io/client-dist/socket.io.min.js"></script>
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript">

			/*window.onload = function(){
				document.getElementById("autoplayaudio").play();
			}
*/
			var ip 		= "127.0.0.1";
			var port 	= "3000";
			var socket 	= io(ip+":"+port);


			$("#message_send").click(function(){
				

				var message = $("#message").val();

				if (message !== "") {

				var user_array_all = [];
				var user_id = "<?php echo $Session->get("user_id"); ?>";
				var current_date = "<?php echo $current_date; ?>";

				user_array_all.push(message);
				user_array_all.push("<?php 
					if ($data) {
							echo $data->user_name; 
						}
					?>");
				user_array_all.push(user_id);
				user_array_all.push(current_date);

				//----For socket start-------

					socket.emit("clientMsgSend", user_array_all);


				//----For socket end-------

				

					$.ajax({
			            url     : "process/process.php",
			            method  : "POST",
			            data    : {
			            	message 		: message,
			            	user_id 		: user_id,
			            	current_date 	: current_date,
			                action 			: "message_sent"
			            },
			            success : function(data){
			        		$("#message").val("");
			            }

			        });

				}


			});

			//----For socket start-------

			socket.on("serverMSGSend", function(data){
				var user_id = "<?php echo $Session->get("user_id"); ?>";

				if (data[2] == user_id) {

					$("#messageShow").append('<div class="mb-2" style="overflow:hidden;"><p style="float:right;background: #6868ca;text-align: right;">'+data[0]+'</p><small style="float:right;padding-right: 45px;display: block;text-align: right;">You '+data[3]+'</small></div>');



			var scrollHeight = document.getElementById('messageShow').scrollHeight;
			$("#messageShow").scrollTop(scrollHeight);




				}else{


					$("#messageShow").append('<div class="mb-2" style="overflow:hidden;"><p style="float:left;background: #9090ae;">'+data[0]+'</p><small style="float:left;padding-left: 45px;display: block;">'+data[1]+' '+data[3]+'</small></div>');



			var scrollHeight = document.getElementById('messageShow').scrollHeight;
			$("#messageShow").scrollTop(scrollHeight);



				}

			});



			$("#message").keyup(function(){

				
				var message = $("#message").val();

				if (message.length > 0) {
					var typemsg = [1,"<?php echo $Session->get("user_id"); ?>","<?php 
					if ($data) {
							echo $data->user_name; 
						}
					?>"];
					socket.emit("typeSendMsg", typemsg);
				}else{
					var typemsg = [0,"<?php echo $Session->get("user_id"); ?>","<?php 
					if ($data) {
							echo $data->user_name; 
						}
					?>"];
					socket.emit("typeSendMsg", typemsg);
				}

			});





			$("#message_send").click(function(){
				var typemsg = [0,"<?php echo $Session->get("user_id"); ?>","<?php 
					if ($data) {
							echo $data->user_name; 
						}
					?>"];
					socket.emit("typeSendMsg", typemsg);
			});





			socket.on("serverTypeSend", function(data){

				if (data[1] !== "<?php echo $Session->get("user_id"); ?>") {


					if (data[0] == 1) {
						$("#typeStatus").html(data[2]+" typing.......");
					}else{
						$("#typeStatus").html("");
					}

				}

			});




			//----For socket end-------




			


				
			$("#logout").click(function(){
				$.ajax({
		            url     : "process/process.php",
		            method  : "get",
		            data    : {
		                action : "logout",
		            },
		            success : function(data){
		        		var getData = $.trim(data);
			            if (getData == 1) {
			             window.location = "login.php";
			            }
		            }

		        });
			});


			var scrollHeight = document.getElementById('messageShow').scrollHeight;
			$("#messageShow").scrollTop(scrollHeight);

		</script>
	</body>
</html>