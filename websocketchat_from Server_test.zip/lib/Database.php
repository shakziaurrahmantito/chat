<?php 
	
	$file = realpath(dirname(__FILE__));
	include_once($file."/../config/config.php");

	class DB{
		private $host = DB_HOST;
		private $user = DB_USER;
		private $password = DB_PASSWORD;
		private $db = DB_NAME;
		public $pdo;

		public function __construct(){
			if (!isset($this->pdo)) {
				$this->pdo = new PDO("mysql:host=".$this->host.";dbname=".$this->db,$this->user,$this->password);
				$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$this->pdo->exec("SET CHARACTER SET utf8");
			}
		}
		
		public function prepare($sql){
			return $this->pdo->prepare($sql);
		}
	}
	

?> 