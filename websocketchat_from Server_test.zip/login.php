<?php
  include_once("lib/session.php");
  $Session  = new Session();
  $Session->init();

  if ($Session->get("login") == 1) {
    header("location:index.php");
  }

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Panel</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- <script src="js/jquery.min.js"></script> -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style type="text/css">
      body{background: #ddd;}
    </style>
  </head>
  <body style="background: #ddd;">

    <section class="my-5 p-3 py-5" style="max-width: 450px;margin: auto;">
      <div class="card">
        <div class="card-body">
          <form class="py-5" method="post" id="userLog">
            <h6 class="text-center text-danger" id="msg"></h6>
            <div class="form-group">
              <label>Email</label>
              <input type="text" name="email" id="email" class="form-control" placeholder="Email address">
              <small id="erremail" class="form-text" style="color:red;"></small>
            </div>
            <div class="form-group">
              <label>Password</label>
              <input type="password" name="password" id="password" class="form-control" placeholder="Password">
              <small id="errpassword" class="form-text" style="color:red;"></small>
            </div>
            <input type="submit" value="Login" class="btn btn-primary">
            <br>
            <a href="singup.php" class="d-block text-center">Create new account</a>
          </form>
          
        </div>
      </div>

    </section>


    <script type="text/javascript">
      

  $("#userLog").submit(function(){

      if ($('#email').val() == "") {
        $("#erremail").text("Field must not be empty.");
        return false;
      }else{
        $("#erremail").text("");
      }

      if ($('#password').val() == "") {
        $("#errpassword").text("Field must not be empty.");
        return false;
      }else{
        $("#errpassword").text("");
      }


      if ($('#email').val() !== "" && $('#password').val() !== "") {

          var email     = $('#email').val();
          var password  = $('#password').val();


          $.ajax({
            url     : "process/process.php",
            method  : "post",
            data    : {
                email : email,
                password : password,
                action : "login",
            },
            success : function(data){
              var getData = $.trim(data);
             if (getData == 1) {
                window.location = "index.php";
              }else if(getData == 2){
                alert("Sorry! your account suspended!");
              }else{
                $("#msg").html("Email or password not match!");
              }
            }

        });

      }

      return false;

    });


    </script>
  </body>
</html>